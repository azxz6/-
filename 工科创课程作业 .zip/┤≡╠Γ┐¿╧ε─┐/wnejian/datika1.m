function varargout = datika1(varargin)
% DATIKA1 MATLAB code for datika1.fig
%      DATIKA1, by itself, creates a new DATIKA1 or raises the existing
%      singleton*.
%
%      H = DATIKA1 returns the handle to a new DATIKA1 or the handle to
%      the existing singleton*.
%
%      DATIKA1('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in DATIKA1.M with the given input arguments.
%
%      DATIKA1('Property','Value',...) creates a new DATIKA1 or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before datika1_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to datika1_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help datika1

% Last Modified by GUIDE v2.5 28-Dec-2023 19:17:53

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @datika1_OpeningFcn, ...
                   'gui_OutputFcn',  @datika1_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before datika1 is made visible.
function datika1_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to datika1 (see VARARGIN)

% Choose default command line output for datika1
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes datika1 wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = datika1_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on button press in pushbutton1.
function pushbutton1_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axis off  %%关闭坐标轴显示
[filename,pathname]=uigetfile({'*.bmp;*.jpg;*.png;*.jpeg;*.tif'},'选择一个图片','F:\test');
str=[pathname filename];
axes(handles.axes1);
guidata(hObject, handles);
handles.img = imread(str);
guidata(hObject, handles);
imshow(handles.img);

% --- Executes on button press in pushbutton2.
function pushbutton2_Callback(hObject, eventdata, handles)
% hObject    handle to pushbutton2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
axis off  %%关闭坐标轴显示
guidata(hObject, handles);
A = handles.img;%读取图像
guidata(hObject, handles);
% % imshow(A),title('原图');
B=rgb2gray(A);
% bw=edge(gray,'canny');%canny算子边缘检测得到二值边缘图像
% [h,t,r]=hough(bw,'RhoResolution',0.5,'ThetaResolution',0.5);                %Hough变换
% % imshow(imadjust(mat2gray(h)),'XData',t,'YData',r,'InitialMagnification','fit'),title('Hough变换矩阵');%显示Hough变换矩阵
% % xlabel('\theta'),ylabel('\rho');
% % axis on, axis normal,hold on;
% P=houghpeaks(h,2);
% x=t(P(:,2));y=r(P(:,1));
% % plot(x,y,'s','color','r'),title('');%获取并标出参数平面的峰值点
% lines=houghlines(bw,t,r,P,'FillGap',5,'Minlength',7);%检测图像中的直线段
% % imshow(gray);
% % hold on;
% max_len=0;
% % for i=1:numel(lines)
% %     xy=[lines(i).point1;lines(i).point2];
% %     plot(xy(:,1),xy(:,2),'LineWidth',2,'Color','g');%用绿色线段标注直线段
% %     plot(xy(:,1),xy(1,2),'x','LineWidth',2,'Color','y');
% %     plot(xy(:,1),xy(2,2),'x','LineWidth',2,'Color','r');%标注直线段端点
% % end
% 
% x=lines.theta;%由与图像边缘平行的直线段的斜率得到整个图像旋转的角度
% B=imrotate(gray,x);%图像修正
% axes(handles.axes2);
% imshow(B),title('旋转后图像');
% imwrite(B,"cc.jpg");

axes(handles.axes2);
TT=graythresh(B);%使用OTSU方法获得阀值T
disp(TT);
result=im2bw(B,0.5);%二值化图像
imshow(result),title('二值化后结果');
imwrite(result,"cp.jpg");

%% 学号识别
n=955;m=505;
interval_length=65;%左右相邻两题填涂区域左边线的距离
interval_width=50;%上下相邻两题填涂区域上边线的距离
length=50;%填涂区域的长度
width=45;%填涂区域的宽度
a2=zeros(10,11);    
for P=1:10
    for Q=1:11
        %m=244;n=52;%第1-5题区域的检测的起始坐标（即第一题A选项左上角的坐标）
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+(Q-1)*(interval_length+1):n+(Q-1)*(interval_length+1)+length);
%         figure
%         imshow(a1);
        %得到矩形区域内各像素的灰度值
        sum1=sum(sum(a1));%计算统计的矩形区域内像素灰度值之和
        a2(P,Q)=sum1;%多次循环后得到20个统计区域的灰度值，并依次放在a2矩阵中
    end
end 
a2(a2<1400)=1;
a2(a2>=1400)=0;
result_xuehao = a2;
str = '';
for i1 = 1:11
    for j1 = 1:10
        if result_xuehao(j1,i1) == 1
            str = [str, num2str(j1 - 1)];
        end
    end
end
set(handles.edit2, 'string', str);

%% 科目识别
n=1750;m=505;
interval_length=55;%左右相邻两题填涂区域左边线的距离
interval_width=100;%上下相邻两题填涂区域上边线的距离
length=55;%填涂区域的长度
width=50;%填涂区域的宽度
a2=zeros(4,1);
for P=1:4
    for Q=1:1
        %m=244;n=52;%第1-5题区域的检测的起始坐标（即第一题A选项左上角的坐标）
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+(Q-1)*(interval_length+1):n+(Q-1)*(interval_length+1)+length);
%         figure
%         imshow(a1);
        %得到矩形区域内各像素的灰度值
        sum1=sum(sum(a1));%计算统计的矩形区域内像素灰度值之和
        a2(P,Q)=sum1;%多次循环后得到20个统计区域的灰度值，并依次放在a2矩阵中
    end
end 
a2(a2<2000)=1;
a2(a2>=2000)=0;
result_xuehao=a2
stro = ["数学","英语","文综","理综"];
for i = 1:4
    if result_xuehao(i,1) == 1
        str = stro(i);
    end
end
set(handles.edit3, 'string', str);

%% 答题区域识别
%扫描区域：在本程序中，有7个扫描区域，分别对应题号为1-5,6-10,11-15,16-20,21-25,26-30,31-35这几个区域
n=275;m=1100;% 首先测得答题区域第一题A选项左上角的坐标（52,244）
s=260;t=400;%s为上下两个扫描区域的距离，t为左右两个扫描区域的距离。
P=4;Q=5;%P为字母项的个数（这里有ABCD共有4项），Q为每个小区域选项数。
interval_length=70;%左右相邻两题填涂区域左边线的距离
interval_width=50;%上下相邻两题填涂区域上边线的距离
length=50;%填涂区域的长度
width=45;%填涂区域的宽度
a2=zeros(4,5);%初始化灰度值统计矩阵

str = '';
stro = ['A','B','C','D'];
%第1-5题区域的检测
for P=1:4
    for Q=1:5
        %m=244;n=52;%第1-5题区域的检测的起始坐标（即第一题A选项左上角的坐标）
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+(Q-1)*(interval_length+1):n+(Q-1)*(interval_length+1)+length);
%         figure
%         imshow(a1);
        %得到矩形区域内各像素的灰度值
        sum1=sum(sum(a1));%计算统计的矩形区域内像素灰度值之和
        a2(P,Q)=sum1;%多次循环后得到20个统计区域的灰度值，并依次放在a2矩阵中

    end
end       


a2(a2<1900)=1;
a2(a2>=1900)=0;%对灰度值统计矩阵里的数值进行处理，大于某一阀值的值赋1，其余的赋0。
             %在此程序中，涂黑则相应数值为1。
result1_5=a2; %存储1-5题的结果

for i1 = 1:5
    for j1 = 1:4
        if result1_5(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end


%第6-10题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*1+(P-1)*(interval_width+1) :m+s*1+(P-1)*(interval_width+1)+width,n+(Q-1)*(interval_length+1):n+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end       

a2(a2<1900)=1;
a2(a2>=1900)=0;
result6_10=a2; %存储6-10题的结果
for i1 = 1:5
    for j1 = 1:4
        if result6_10(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end


%第11-15题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+t*1+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end     
a2(a2<1900)=1;
a2(a2>=1900)=0;
result11_15=a2; %存储11-15题的结果
for i1 = 1:5
    for j1 = 1:4
        if result11_15(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end
%第16-20题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*1+(P-1)*(interval_width+1) :m+s*1+(P-1)*(interval_width+1)+width , n+t*1+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result16_20=a2; %存储16-20题的结果
for i1 = 1:5
    for j1 = 1:4
        if result16_20(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第21-25题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*2+(P-1)*(interval_width+1) :m+s*2+(P-1)*(interval_width+1)+width,n+t*1+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result21_25=a2; %存储21-25题的结果
for i1 = 1:5
    for j1 = 1:4
        if result21_25(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第26-30题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*3+(P-1)*(interval_width+1) :m+s*3+(P-1)*(interval_width+1)+width,n+t*1+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result26_30=a2; %存储26-30题的结果
for i1 = 1:5
    for j1 = 1:4
        if result26_30(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第31-35题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*4+(P-1)*(interval_width+1) :m+s*4+(P-1)*(interval_width+1)+width,n+t*1+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end     
a2(a2<1900)=1;
a2(a2>=1900)=0;
result31_35=a2; %存储31-35题的结果
for i1 = 1:5
    for j1 = 1:4
        if result31_35(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第36-40题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+t*2+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end     
a2(a2<1900)=1;
a2(a2>=1900)=0;
result36_40=a2; 
for i1 = 1:5
    for j1 = 1:4
        if result36_40(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第41-45题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*1+(P-1)*(interval_width+1) :m+s*1+(P-1)*(interval_width+1)+width , n+t*2+(Q-1)*(interval_length+1):n+t*2+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result41_45=a2; %存储16-20题的结果
for i1 = 1:5
    for j1 = 1:4
        if result41_45(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第46_50题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*2+(P-1)*(interval_width+1) :m+s*2+(P-1)*(interval_width+1)+width,n+t*2+(Q-1)*(interval_length+1):n+t*2+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result46_50=a2; %存储21-25题的结果
for i1 = 1:5
    for j1 = 1:4
        if result46_50(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第51_55题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*3+(P-1)*(interval_width+1) :m+s*3+(P-1)*(interval_width+1)+width,n+t*2+(Q-1)*(interval_length+1):n+t*2+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result51_55=a2; %存储26-30题的结果
for i1 = 1:5
    for j1 = 1:4
        if result51_55(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第56-60题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*4+(P-1)*(interval_width+1) :m+s*4+(P-1)*(interval_width+1)+width,n+t*2+(Q-1)*(interval_length+1):n+t*2+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end     
a2(a2<1900)=1;
a2(a2>=1900)=0;
result56_60=a2; %存储31-35题的结果
for i1 = 1:5
    for j1 = 1:4
        if result56_60(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第61-65题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+(P-1)*(interval_width+1) :m+(P-1)*(interval_width+1)+width,n+t*2+(Q-1)*(interval_length+1):n+t*1+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end     
a2(a2<1900)=1;
a2(a2>=1900)=0;
result61_65=a2; %存储11-15题的结果
for i1 = 1:5
    for j1 = 1:4
        if result61_65(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第66-70题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*1+(P-1)*(interval_width+1) :m+s*1+(P-1)*(interval_width+1)+width , n+t*3+(Q-1)*(interval_length+1):n+t*3+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result66_70=a2; %存储16-20题的结果
for i1 = 1:5
    for j1 = 1:4
        if result66_70(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第71-75题区域的检测
for P=1:4
    for Q=1:5
        a1=result(m+s*2+(P-1)*(interval_width+1) :m+s*2+(P-1)*(interval_width+1)+width,n+t*3+(Q-1)*(interval_length+1):n+t*3+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result71_75=a2;
for i1 = 1:5
    for j1 = 1:4
        if result71_75(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第76-80题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*3+(P-1)*(interval_width+1) :m+s*3+(P-1)*(interval_width+1)+width,n+t*3+(Q-1)*(interval_length+1):n+t*3+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end   

a2(a2<1900)=1;
a2(a2>=1900)=0;
result76_80=a2; 
for i1 = 1:5
    for j1 = 1:4
        if result76_80(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end

%第81-85题区域的检测
for P=1:4
    for Q=1:5
       a1=result(m+s*4+(P-1)*(interval_width+1) :m+s*4+(P-1)*(interval_width+1)+width,n+t*3+(Q-1)*(interval_length+1):n+t*3+(Q-1)*(interval_length+1)+length);
        sum1=sum(sum(a1));
        a2(P,Q)=sum1;

    end
end                                        
a2(a2<1900)=1;
a2(a2>=1900)=0;
result81_85=a2; 
for i1 = 1:5
    for j1 = 1:4
        if result81_85(j1,i1) == 1
            str = [str, stro(j1)];
        end
    end
end
% set(handles.edit4, 'string', str);


data = readtable('answer.xlsx');

% 获取第二列的第二行到第86行的数据 
column2 = data{:, 2};

% 将数据拼接成一个字符串
result = strjoin(column2);

% 显示结果
disp(result);

num1 = 0;
for i = 1:85
    if result(i) == str(i)
        num1 = num1 + 1;
    end
end
disp(num1);
set(handles.edit5, 'string', num2str(num1));
if num1 < 60
    set(handles.edit6, 'string', '未通过');
else
    set(handles.edit6, 'string', '通过');
end


% answer=[result1_5,result6_10,result11_15,result16_20,result21_25,result26_30,result31_35,result36_40,result41_45,result46_50,result51_55,result56_60,result61_65,result66_70,result71_75,result76_80,result81_85];%将所检测的7个区域的结果汇总 ,result31_35
% 
% dlmwrite('Result.txt',answer);%以txt文本的形式输出结果矩阵
% 
% % disp(answer);%在command窗口实时显示结果
% 
% %附加一个统计错误的并显示分数的部分，假定正确答案是35个C
% T=zeros(4,85);%初始化矩阵 35 
% T(1,:)=1;%设定正确答案的参数
% mark1=answer-T;
% wrongx=sum(mark1~=0);%当结果选错时，每一列将分别多一个1与-1。选择正确时，此列都是0。
% A=sum(sum(wrongx));%统计非零的结果。
% wrong=A/2;%由于-1与1是成对出现的，所以需要将上一步所得结果除以2.
% score=85-wrong;%算出结果  30


% fprintf('选择题得分为%d',score);%在command窗口输出成绩



function edit2_Callback(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit2 as text
%        str2double(get(hObject,'String')) returns contents of edit2 as a double


% --- Executes during object creation, after setting all properties.
function edit2_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit2 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit3_Callback(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit3 as text
%        str2double(get(hObject,'String')) returns contents of edit3 as a double


% --- Executes during object creation, after setting all properties.
function edit3_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit3 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit4_Callback(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit4 as text
%        str2double(get(hObject,'String')) returns contents of edit4 as a double


% --- Executes during object creation, after setting all properties.
function edit4_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit4 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit5_Callback(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit5 as text
%        str2double(get(hObject,'String')) returns contents of edit5 as a double


% --- Executes during object creation, after setting all properties.
function edit5_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit5 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit6_Callback(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit6 as text
%        str2double(get(hObject,'String')) returns contents of edit6 as a double


% --- Executes during object creation, after setting all properties.
function edit6_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit6 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end
